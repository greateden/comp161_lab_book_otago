/** Lab 2 COMP161 TwoNumbersApp.java
* (your name) November 2022 */
public class TwoNumbersApp{
   public static void main (String[] args){
      double num1;//declaration, specifies data type and name
      double num2;
      num1 = 3.5; //assignment
      num2 = 12.0;
      System.out.println("First number is " + num1);
      System.out.println("Second number is " + num2);
      System.out.println("Sum is " + (num1 + num2));
   }
}
