/** Lab 2 COMP161 TwoNumbersApp.java
* The Greatest Eden November 2022 */
public class ThreeNumbersApp{
   public static void main (String[] args){
      double num1;//declaration, specifies data type and name
      double num2;
      int num3 = 1;
      num1 = 3.5; //assignment
      num2 = 12.0;
      double sum = num1 + num2 + num3;
      System.out.println("First number is " + num1);
      System.out.println("Second number is " + num2);
      System.out.println("Third number is " + num3);
      System.out.println("Sum is " + sum);
   }
}
