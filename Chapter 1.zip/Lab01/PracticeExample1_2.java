public class PracticeExample2
  public static void main(String()args):
      System.out.println("What is the capital of Australia")
      System.out.println("A")
 
