Public Class PracticeExample1_1{
  Public Static Void main(String[]args){
      System.Out.PrintLn('COMP161');
      System.Out.PrintLn('18 points');
   }
}
