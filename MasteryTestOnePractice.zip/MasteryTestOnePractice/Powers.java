public class Powers {
   public static void main(String[] args) {
      int number = 5;
      System.out.printf("The first 3 powers of %d are: ", number);
      System.out.printf("%d, %d, %d%n", number * number, 
                        (int)Math.pow(number, 3), (int)Math.pow(number, 4));
   }
}
