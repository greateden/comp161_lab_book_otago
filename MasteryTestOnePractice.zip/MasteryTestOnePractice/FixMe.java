/**
 * Mastery Test 1 Practice, Section 1, Q1
 */
public class FixMe {
    public static void main(String[] args) {
        int num1 = 2;
        int num2 = 4;

        // Print interesting fact
        System.out.printf("An interesting fact: %d times %d is %d!%n", 
            num1, num2, num1 * num2);
    }
}