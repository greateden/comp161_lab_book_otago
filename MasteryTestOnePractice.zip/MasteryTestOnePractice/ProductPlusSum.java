public class ProductPlusSum {
    public static void main(String[] args) {
        int x = 7;
        int y = 9;
        int z = 3;
        int answer = x * y * z + x + y + z;
        String phrase = String.format("The product of %d, %d, and %d plus "
                                    + "the sum of %d, %d, and %d is: %d",
                                      x, y, z, x, y, z, answer);
        System.out.println(phrase);
    }
}
