/**
 * Mastery Test 1 Practice, Section 2, Q3
 */
public class MakeASum {
    private static final int NUM1 = 4;
    private static final int NUM2 = 5;
    private static final int NUM3 = 6;
    
    public static void main(String[] args) {
        int result = (NUM1 + NUM2) * 8 + NUM3 / 3;
        System.out.println("The result is: " + result);
    }
}