/**
 * Mastery Test 1 Practice, Section 2, Q1
 */
public class BabyShark {
    private static final String SHARK = "Baby shark";
    private static final String DOO = ", doo doo doo doo doo doo";

    public static void main(String[] args) {
        for (int i = 1; i <= 3; i++) {
            System.out.println(SHARK + DOO);
        }
        System.out.println(SHARK + "!");
    }
}