public class PracticeQuestion1 {
   public static void main(String[] args) {
      int n1 = 7;
      int n2 = 3;
      int n3 = 5;

      int result = n2 * 100 + n3 * 10 + n1 + n2 / 3 * 2;
      System.out.println("Eden Li " + result);
   }
}