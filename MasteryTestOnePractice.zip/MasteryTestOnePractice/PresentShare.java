/**
 * Section 2, Question 1 of Mastery Test 1
 */
public class PresentShare {
    public static void main(String[] args) {
        String birthdayPerson = "Aroha";
        int numberOfFriends = 7;
        double amountPerFriend = 15.5;

        double totalAmount = numberOfFriends * amountPerFriend;

        String message = String.format("Together you can spend $%.2f to buy a present for %s!", totalAmount, birthdayPerson);

        System.out.println(message);
    }
}